# Ideal Client Profile: Inspire Wealth Partners

## Who they are
Three groups, named directly in your own letters:

1. **Individuals retired or thinking about it in the next five years.** People at the transition point where a portfolio has to start producing income instead of just accumulating it.
2. **Small-business owners.** People whose financial life is tangled up with a business they built, not just a 401(k) and a brokerage account.
3. **Individuals with equity compensation.** People navigating stock options, RSUs, or concentrated positions that come with genuine tax and timing complexity.

## What they care about
- **Being known, not processed.** They want an advisor who remembers their kids' names and their business's history, not a call-center rotation.
- **Understanding their own plan.** They're not satisfied nodding along at an annual review. They want to know why a recommendation makes sense, in language that doesn't require a finance degree.
- **Fair, transparent pricing.** They notice when a fee structure benefits the advisor more than them, and they'd rather pay a flat number they can predict than a percentage that keeps climbing on its own.
- **A long relationship over a quick sale.** They're not shopping for a product. They're looking for someone they'll still be working with in twenty years.

## Their values
- **Trust is earned slowly and referred forward.** Nearly every client in your practice arrived through a friend's recommendation, which tells you they value word-of-mouth from people they already trust over advertising or rankings.
- **They'd rather be one of a manageable number of relationships than a number in a book of thousands.** Capacity and attention matter to them as much as returns.
- **They're comfortable with a slower, more deliberate pace** if it means the advice is actually right for their situation, echoing your own belief in active patience.
- **Life comes first, money is the tool.** These are people planning around retirement, family, or a business they've built, not people chasing performance for its own sake. They're drawn to the idea that a financial plan should serve a fuller life, not the other way around.

## Who they are not
People shopping purely on returns, comfortable with a call-center-style advisory relationship, or looking for the cheapest possible AUM percentage regardless of service quality. Also not a fit: anyone who wants a transactional, one-time trade recommendation rather than an ongoing planning relationship (you'll help them find someone better suited on an hourly basis instead).
