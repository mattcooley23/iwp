# Tone of Voice Guide: Matt Cooley / Inspire Wealth Partners

## The overall sound
Warm, plainspoken, and a little self-deprecating. You write like you're catching up with a friend rather than issuing a firm update: family news sits right next to business news in the same paragraph, and neither gets treated as more important than the other. There's a current of gratitude running under almost everything, but it never tips into false modesty. You'll state a genuinely strong result, like growing 187% faster than top-performing firms, and then immediately hand the credit somewhere else: to clients, to God, to circumstance.

You're comfortable being countercultural and saying so directly. Capping growth on purpose, refusing AUM fees, turning away clients who aren't a fit--these are choices you name outright rather than downplay. The confidence comes from conviction, not swagger.

## Words and phrases you use
- **grateful, humbled, honored:** your default register for describing success
- **organically, compound, steadily:** how you describe growth, always in contrast to anything that smells like a sales push
- **bespoke, intentional, purpose-driven:** how you describe the client experience
- **countercultural, radically different, opportunity cost:** how you frame decisions that go against industry norms
- **obvious, apparent:** used when explaining a realization that took time to arrive at
- **onward, all the best:** closing lines
- Direct address to the reader, e.g. "If you or someone you know..."
- Parenthetical asides that puncture your own seriousness, like "(guess who really pays for that stuff?)" and "(countercultural, I know)"

## Words and phrases you avoid
- Industry jargon and acronym-heavy language. You'll say plainly what a percentage fee costs someone rather than leaning on a term like "basis points" without translating it.
- Hype language and superlatives without a number behind them.
- Bragging without follow-through. When you cite an impressive stat, you always explain why it happened, in plain terms, rather than letting the number sit there on its own.

## Sentence patterns
- **Anaphora, or repeated structure, to build an argument.** Your Reflections letter runs almost entirely on "Instead of X, we could Y," with each line building the case before you name the conclusion.
- **Numbered lists to justify a claim.** When you assert something, like the three reasons behind IWP's growth, you back it with a clean, numbered breakdown instead of a paragraph of prose.
- **Short declarative sentences used as pivots.** "Parenthood is the greatest gift and joy of our lifetimes." "I never cold call." These land as standalone beats. You typically follow one with a longer, more explanatory sentence rather than another short one.
- **Data paired with a plain-English translation.** You don't cite a stat and move on. You explain what it means in dollars or years for an actual client.
- **Self-aware asides in parentheses** that name the elephant in the room before someone else can point it out.

## Signature sign-off
> All the best (or: Onward),
> Matt Cooley, CFP®
> Founder | Inspire Wealth Partners

## Direct quotes worth studying
- "I believed financial advice could and should be different."
- "Instead of selling complexity, we could have simple financial conversations that were free of industry jargon."
- "Instead of trying to fit everyone in the same box, we could build boxes around each and every client."

*(All three from the Reflections on 5 Years letter.)*
