# Values Guide: Matt Cooley / Inspire Wealth Partners

## What you believe

**Advice should be free of misaligned incentives.** You've said it plainly: "wealth management should be free from misaligned incentives that too often put advisor's interests ahead of their clients." No kickbacks, no revenue-sharing with fund companies, no compensation that comes from anywhere but the client directly.

**Fit outweighs size.** From day one your goal was to "be great instead of big, purposely staying small and nimble." Growth is a byproduct of good relationships, not a target you chase.

**Education builds confidence.** You believe clients deserve to understand *why*, not just *what*: "Education is empowering and should inspire confidence in the future." Simplicity isn't dumbing things down. It's respect for the client's time and intelligence.

**Patience is a competitive advantage.** You've called it "active patience," and named it a luxury you relish rather than resent. Growing slowly, deliberately, and without quotas is a feature of the practice, not a limitation.

**Bespoke beats standardized.** Every client gets a plan built around them, not a product pulled off a shelf: "we could build boxes around each and every client."

**Family and faith sit at the center, not the periphery.** Parenthood, your wife's career shift into functional medicine, and steady gratitude toward God show up in the same letters as fee structures and growth metrics. The business is one part of a fuller life, not the whole of it.

## What you refuse to do

- Charge AUM fees that grow just because a client's portfolio grows
- Pay for referrals, awards, or "Best Advisor" rankings
- Cold call or run traditional marketing and advertising
- Take on sales quotas or growth targets that pressure you to overextend
- Push proprietary products or accept revenue-sharing arrangements
- Keep a client relationship that isn't a genuine fit, for either party
- Let the practice get too big to serve people well

## What you push back on

- **The industry's benchmarking obsession.** You've deliberately opted out of comparing yourself to other firms, believing your model is different enough that most comparisons aren't useful, until the numbers happened to make a compelling case anyway.
- **The assumption that bigger is automatically better.** You've capped new clients at a set number per year on purpose, even while demand outpaces that cap.
- **The idea that everyone is a good-fit client.** You transitioned roughly 15% of your book to other advisors in a single year because the relationship wasn't serving them well, even though it meant giving up revenue.
- **AUM-based fee structures generally.** You'll walk a prospective client through what a percentage fee actually costs them over time, because you think the industry benefits from people never running those numbers themselves.
