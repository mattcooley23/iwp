# Content Pillar Outline: Inspire Wealth Partners

Five topical territories, each grounded in something you've already said in the letters, with a direct quote as the anchor.

## 1. The flat-fee case against AUM pricing
Your clearest, most quantifiable argument. You have concrete dollar examples ready to go: a client whose fee started near industry average and now sits thousands per year below it, purely because the fee doesn't climb with the portfolio.

> "If you are paying a percentage of your portfolio, the cost of your financial advice increases with your portfolio value."

Content angles: fee-structure comparisons, "what a percentage fee actually costs over ten years," case studies using your own client examples (anonymized), a running series revisiting the numbers each year as the gap widens.

## 2. Small on purpose
The choice to stay capped, solo, and referral-only isn't a limitation you're managing around. It's the model.

> "Our intention is to be great instead of big, purposely staying small and nimble."

Content angles: why you cap new clients per year, what gets lost when a practice scales past a certain size, the tradeoffs of growth for growth's sake, your reasoning for staying solo rather than building a team.

## 3. Saying no to the wrong fit
One of your most distinctive moves: transitioning existing clients elsewhere when the relationship isn't right, even at a direct cost to revenue.

> "It quickly became apparent and obvious that accepting anyone that walked through the door could be a disservice to them."

Content angles: how you define fit, the criteria that make someone a good candidate for the practice (or not), what happens when a client outgrows the relationship, honest talk about the cost of turning business away.

## 4. Financial advice without the jargon
Your foundational belief that education, not complexity, builds trust.

> "Instead of selling complexity, we could have simple financial conversations that were free of industry jargon."

Content angles: plain-English breakdowns of concepts advisors usually over-complicate, a recurring "translate this term" format, the reasoning behind reviewing more than just portfolio performance at annual meetings.

## 5. Building a life, not just a portfolio
The through-line connecting parenthood, faith, and financial planning: money as a means to a fuller life, not the goal itself.

> "I believed Inspire Wealth Partners could also be a platform to inspire clients to live joyfully and fulfilled."

Content angles: what "purpose-driven planning" looks like in practice, stories from your own life stage (raising three kids, balancing family and founding a firm) that mirror what clients are navigating, retirement and equity-comp planning framed around life goals rather than account balances.
